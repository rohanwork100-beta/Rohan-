import { describe, expect, it } from "vitest";
import { safeFileName } from "./routers";

describe("file storage helpers", () => {
  it("removes path characters before creating a storage key", () => {
    expect(safeFileName("../../private notes/launch plan.pdf")).toBe("..-..-private-notes-launch-plan.pdf");
  });

  it("provides a safe fallback for blank names", () => {
    expect(safeFileName("   ")).toBe("attachment");
  });

  it("keeps common file extensions and caps long names", () => {
    const name = `${"a".repeat(200)}.png`;
    const sanitized = safeFileName(name);
    expect(sanitized.endsWith(".png")).toBe(true);
    expect(sanitized.length).toBeLessThanOrEqual(140);
  });
});
