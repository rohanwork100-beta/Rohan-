import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { deleteNoteFile, insertNoteFile, listNoteFiles } from "./db";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { storagePut } from "./storage";

export function safeFileName(name: string) {
  const cleaned = name.trim().replace(/[^a-zA-Z0-9._-]/g, "-") || "attachment";
  if (cleaned.length <= 140) return cleaned;
  const extensionIndex = cleaned.lastIndexOf(".");
  const extension = extensionIndex > 0 ? cleaned.slice(extensionIndex) : "";
  const stem = cleaned.slice(0, extensionIndex > 0 ? extensionIndex : cleaned.length);
  return `${stem.slice(0, Math.max(1, 140 - extension.length))}${extension}`;
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  files: router({
    list: protectedProcedure.query(({ ctx }) => listNoteFiles(ctx.user.id)),
    upload: protectedProcedure
      .input(z.object({
        name: z.string().min(1).max(255),
        mimeType: z.string().min(1).max(128),
        size: z.number().int().positive().max(10 * 1024 * 1024),
        noteId: z.string().max(128).optional(),
        data: z.string().min(1),
      }))
      .mutation(async ({ ctx, input }) => {
        const buffer = Buffer.from(input.data, "base64");
        if (buffer.length !== input.size) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "File size validation failed" });
        }
        const fileName = safeFileName(input.name);
        const uploaded = await storagePut(`${ctx.user.id}/notes/${fileName}`, buffer, input.mimeType);
        const saved = await insertNoteFile({
          userId: ctx.user.id,
          noteId: input.noteId,
          name: input.name,
          mimeType: input.mimeType,
          size: input.size,
          storageKey: uploaded.key,
          storageUrl: uploaded.url,
        });
        return saved;
      }),
    remove: protectedProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .mutation(({ ctx, input }) => deleteNoteFile(ctx.user.id, input.id)),
  }),
});

export type AppRouter = typeof appRouter;
