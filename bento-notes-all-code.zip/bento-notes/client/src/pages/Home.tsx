import { useEffect, useMemo, useRef, useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { trpc } from "@/lib/trpc";
import {
  Archive,
  ArrowDownAZ,
  Bell,
  BookOpen,
  Check,
  CheckCircle2,
  ChevronDown,
  Circle,
  Cloud,
  ExternalLink,
  FileUp,
  Command,
  Download,
  FileText,
  Folder,
  Hash,
  Inbox,
  LayoutGrid,
  Lightbulb,
  List,
  Moon,
  MoreHorizontal,
  Pencil,
  Pin,
  Plus,
  RotateCcw,
  Search,
  Settings2,
  Sparkles,
  Star,
  Sun,
  Tag,
  Trash2,
  Upload,
  X,
  Zap,
} from "lucide-react";

type NoteColor = "lavender" | "sage" | "peach" | "sky" | "butter" | "rose";
type ViewKey = "all" | "pinned" | "favorites" | "archive" | "trash";

type Note = {
  id: string;
  title: string;
  content: string;
  tag: string;
  category: string;
  color: NoteColor;
  createdAt: string;
  updatedAt: string;
  pinned?: boolean;
  favorite?: boolean;
  archived?: boolean;
  trashed?: boolean;
};

const seedNotes: Note[] = [
  {
    id: "n1",
    title: "The quiet advantage",
    content: "The best ideas rarely arrive on demand. They find you when the noise is low and your attention has room to wander.\n\nMake space before asking for answers.",
    tag: "Writing",
    category: "Ideas",
    color: "lavender",
    createdAt: "2026-09-16T08:40:00.000Z",
    updatedAt: "2026-09-16T08:40:00.000Z",
    pinned: true,
    favorite: true,
  },
  {
    id: "n2",
    title: "Product principles",
    content: "01  Make the useful thing obvious\n02  Remove one more step\n03  Design for the returning user\n04  Leave room for delight",
    tag: "Work",
    category: "Product",
    color: "sage",
    createdAt: "2026-09-15T15:20:00.000Z",
    updatedAt: "2026-09-15T15:20:00.000Z",
    pinned: true,
  },
  {
    id: "n3",
    title: "Weekend in Kyoto",
    content: "Coffee at Weekenders · Philosopher's Path · Nishiki Market\n\nPack the little film camera. Book the small ryokan near Gion. Leave Sunday open.",
    tag: "Personal",
    category: "Travel",
    color: "peach",
    createdAt: "2026-09-14T10:12:00.000Z",
    updatedAt: "2026-09-14T10:12:00.000Z",
    favorite: true,
  },
  {
    id: "n4",
    title: "Reading list",
    content: "— The Creative Act, Rick Rubin\n— The Overstory, Richard Powers\n— Ways of Seeing, John Berger\n— The Book of Delights, Ross Gay",
    tag: "Reading",
    category: "Reference",
    color: "sky",
    createdAt: "2026-09-13T09:10:00.000Z",
    updatedAt: "2026-09-13T09:10:00.000Z",
  },
  {
    id: "n5",
    title: "Morning reset",
    content: "Open the window\nDrink a full glass of water\nWrite the one thing\nMove for ten minutes",
    tag: "Life",
    category: "Rituals",
    color: "butter",
    createdAt: "2026-09-12T06:30:00.000Z",
    updatedAt: "2026-09-12T06:30:00.000Z",
    favorite: true,
  },
  {
    id: "n6",
    title: "Launch checklist",
    content: "✓ Finalize onboarding flow\n✓ QA the empty states\n○ Write announcement\n○ Schedule release notes",
    tag: "Work",
    category: "Product",
    color: "rose",
    createdAt: "2026-09-11T16:00:00.000Z",
    updatedAt: "2026-09-11T16:00:00.000Z",
  },
];

const colors: NoteColor[] = ["lavender", "sage", "peach", "sky", "butter", "rose"];
const navItems: { key: ViewKey; label: string; icon: typeof Inbox }[] = [
  { key: "all", label: "All notes", icon: Inbox },
  { key: "pinned", label: "Pinned", icon: Pin },
  { key: "favorites", label: "Favorites", icon: Star },
  { key: "archive", label: "Archive", icon: Archive },
  { key: "trash", label: "Trash", icon: Trash2 },
];

function formatDate(date: string) {
  const d = new Date(date);
  const now = new Date("2026-09-16T18:00:00.000Z");
  const diff = Math.floor((now.getTime() - d.getTime()) / 86400000);
  if (diff === 0) return "Today";
  if (diff === 1) return "Yesterday";
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

function makeId() {
  return `n-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}

function AppLogo() {
  return (
    <div className="brand-mark" aria-label="Bento Notes">
      <span className="brand-dot dot-a" />
      <span className="brand-dot dot-b" />
      <span className="brand-dot dot-c" />
      <span className="brand-dot dot-d" />
    </div>
  );
}

function NoteCard({
  note,
  index,
  onOpen,
  onPin,
  onFavorite,
  onArchive,
  onDelete,
  onRestore,
}: {
  note: Note;
  index: number;
  onOpen: (note: Note) => void;
  onPin: (id: string) => void;
  onFavorite: (id: string) => void;
  onArchive: (id: string) => void;
  onDelete: (id: string) => void;
  onRestore: (id: string) => void;
}) {
  const isTrash = note.trashed;
  return (
    <article className={`note-card note-${note.color} card-index-${index % 5} ${note.pinned ? "is-pinned" : ""}`}>
      <div className="note-card-top">
        <span className="note-tag"><span className="tag-dot" />{note.tag}</span>
        <div className="note-card-actions">
          <button className={`icon-button tiny ${note.pinned ? "active" : ""}`} onClick={() => onPin(note.id)} aria-label={note.pinned ? "Unpin note" : "Pin note"} title={note.pinned ? "Unpin" : "Pin"}><Pin size={14} /></button>
          <button className={`icon-button tiny ${note.favorite ? "active-star" : ""}`} onClick={() => onFavorite(note.id)} aria-label={note.favorite ? "Remove favorite" : "Favorite note"} title={note.favorite ? "Unfavorite" : "Favorite"}><Star size={14} fill={note.favorite ? "currentColor" : "none"} /></button>
          <button className="icon-button tiny" onClick={() => (isTrash ? onRestore(note.id) : onDelete(note.id))} aria-label={isTrash ? "Restore note" : "Delete note"} title={isTrash ? "Restore" : "Delete"}>{isTrash ? <RotateCcw size={14} /> : <Trash2 size={14} />}</button>
          {!isTrash && <button className="icon-button tiny" onClick={() => onArchive(note.id)} aria-label={note.archived ? "Unarchive note" : "Archive note"} title={note.archived ? "Unarchive" : "Archive"}><Archive size={14} /></button>}
        </div>
      </div>
      <button className="note-card-body" onClick={() => onOpen(note)}>
        <h3>{note.title || "Untitled note"}</h3>
        <p>{note.content || "Start writing something beautiful..."}</p>
      </button>
      <div className="note-card-footer">
        <span>{formatDate(note.updatedAt)}</span>
        <button className="edit-chip" onClick={() => onOpen(note)}><Pencil size={12} /> Edit</button>
      </div>
    </article>
  );
}

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const filesQuery = trpc.files.list.useQuery(undefined, { enabled: isAuthenticated, retry: false });
  const uploadFile = trpc.files.upload.useMutation({
    onSuccess: () => {
      filesQuery.refetch();
      setToast("File saved to cloud storage");
    },
    onError: (error) => setToast(error.message || "Upload failed"),
  });
  const removeFile = trpc.files.remove.useMutation({
    onSuccess: () => {
      filesQuery.refetch();
      setToast("File removed from your library");
    },
    onError: (error) => setToast(error.message || "Could not remove file"),
  });
  const [notes, setNotes] = useState<Note[]>(() => {
    try {
      const stored = localStorage.getItem("bento-notes-data");
      return stored ? JSON.parse(stored) : seedNotes;
    } catch {
      return seedNotes;
    }
  });
  const [view, setView] = useState<ViewKey>("all");
  const [search, setSearch] = useState("");
  const [tagFilter, setTagFilter] = useState("All tags");
  const [sort, setSort] = useState<"updated" | "created" | "title">("updated");
  const [layout, setLayout] = useState<"grid" | "list">("grid");
  const [theme, setTheme] = useState<"dark" | "light">(() => (localStorage.getItem("bento-notes-theme") as "dark" | "light") || "dark");
  const [editorOpen, setEditorOpen] = useState(false);
  const [editing, setEditing] = useState<Note | null>(null);
  const [toast, setToast] = useState("");
  const [storageOpen, setStorageOpen] = useState(false);
  const searchRef = useRef<HTMLInputElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const cloudFileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    localStorage.setItem("bento-notes-data", JSON.stringify(notes));
  }, [notes]);

  useEffect(() => {
    document.body.dataset.theme = theme;
    localStorage.setItem("bento-notes-theme", theme);
  }, [theme]);

  useEffect(() => {
    const handleKeys = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        searchRef.current?.focus();
      }
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "n") {
        event.preventDefault();
        openNewNote();
      }
      if (event.key === "Escape" && editorOpen) setEditorOpen(false);
    };
    window.addEventListener("keydown", handleKeys);
    return () => window.removeEventListener("keydown", handleKeys);
  }, [editorOpen]);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(""), 2400);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const tags = useMemo(() => ["All tags", ...Array.from(new Set(notes.filter((n) => !n.trashed).map((n) => n.tag)))], [notes]);
  const visibleNotes = useMemo(() => {
    const q = search.trim().toLowerCase();
    return notes
      .filter((note) => {
        if (view === "trash") return note.trashed;
        if (view === "archive") return note.archived && !note.trashed;
        if (note.trashed || note.archived) return false;
        if (view === "pinned" && !note.pinned) return false;
        if (view === "favorites" && !note.favorite) return false;
        if (tagFilter !== "All tags" && note.tag !== tagFilter) return false;
        if (!q) return true;
        return `${note.title} ${note.content} ${note.tag} ${note.category}`.toLowerCase().includes(q);
      })
      .sort((a, b) => {
        if (sort === "title") return a.title.localeCompare(b.title);
        return new Date(b[sort === "created" ? "createdAt" : "updatedAt"]).getTime() - new Date(a[sort === "created" ? "createdAt" : "updatedAt"]).getTime();
      });
  }, [notes, view, search, tagFilter, sort]);

  const stats = useMemo(() => ({
    total: notes.filter((n) => !n.trashed && !n.archived).length,
    pinned: notes.filter((n) => n.pinned && !n.trashed).length,
    words: notes.filter((n) => !n.trashed).reduce((acc, n) => acc + n.content.trim().split(/\s+/).filter(Boolean).length, 0),
  }), [notes]);

  function openNewNote() {
    setEditing({ id: makeId(), title: "", content: "", tag: "Inbox", category: "Quick capture", color: "lavender", createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
    setEditorOpen(true);
  }

  function updateNote(id: string, patch: Partial<Note>) {
    setNotes((current) => current.map((note) => note.id === id ? { ...note, ...patch, updatedAt: new Date().toISOString() } : note));
  }

  function saveNote(note: Note) {
    if (!note.title.trim() && !note.content.trim()) {
      setEditorOpen(false);
      return;
    }
    setNotes((current) => current.some((n) => n.id === note.id) ? current.map((n) => n.id === note.id ? { ...note, title: note.title.trim() || "Untitled note", updatedAt: new Date().toISOString() } : n) : [{ ...note, title: note.title.trim() || "Untitled note", updatedAt: new Date().toISOString() }, ...current]);
    setEditorOpen(false);
    setToast("Note saved");
  }

  function toggleField(id: string, field: "pinned" | "favorite") {
    setNotes((current) => current.map((note) => note.id === id ? { ...note, [field]: !note[field], updatedAt: new Date().toISOString() } : note));
  }

  function archiveNote(id: string) {
    setNotes((current) => current.map((note) => note.id === id ? { ...note, archived: !note.archived, updatedAt: new Date().toISOString() } : note));
    setToast("Archive updated");
  }

  function deleteNote(id: string) {
    setNotes((current) => current.map((note) => note.id === id ? { ...note, trashed: true, updatedAt: new Date().toISOString() } : note));
    setToast("Moved to trash");
  }

  function restoreNote(id: string) {
    setNotes((current) => current.map((note) => note.id === id ? { ...note, trashed: false, archived: false, updatedAt: new Date().toISOString() } : note));
    setToast("Note restored");
  }

  function exportNotes() {
    const blob = new Blob([JSON.stringify(notes, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `bento-notes-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setToast("Notes exported");
  }

  function importNotes(event: React.ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const incoming = JSON.parse(String(reader.result));
        if (Array.isArray(incoming)) {
          setNotes(incoming);
          setToast("Notes imported");
        }
      } catch {
        setToast("Could not import that file");
      }
    };
    reader.readAsText(file);
    event.target.value = "";
  }

  function openStorage() {
    if (!isAuthenticated) {
      startLogin();
      return;
    }
    setStorageOpen(true);
  }

  function uploadCloudFile(event: React.ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    if (file.size > 10 * 1024 * 1024) {
      setToast("Files must be 10 MB or smaller");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const result = String(reader.result);
      const data = result.includes(",") ? result.split(",")[1] : result;
      uploadFile.mutate({ name: file.name, mimeType: file.type || "application/octet-stream", size: file.size, data });
    };
    reader.readAsDataURL(file);
  }

  const activeLabel = navItems.find((item) => item.key === view)?.label || "All notes";

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand-row"><AppLogo /><span className="brand-name">bento<span>.</span></span><span className="brand-beta">notes</span></div>
        <button className="new-note-button" onClick={openNewNote}><Plus size={18} strokeWidth={2.5} /><span>New note</span><kbd>⌘ N</kbd></button>

        <div className="sidebar-label">Workspace</div>
        <nav className="sidebar-nav" aria-label="Notes views">
          {navItems.map(({ key, label, icon: Icon }) => {
            const count = key === "all" ? stats.total : key === "pinned" ? stats.pinned : key === "favorites" ? notes.filter((n) => n.favorite && !n.trashed).length : key === "trash" ? notes.filter((n) => n.trashed).length : notes.filter((n) => n.archived && !n.trashed).length;
            return <button key={key} className={`nav-item ${view === key ? "selected" : ""}`} onClick={() => setView(key)}><Icon size={17} strokeWidth={1.8} /><span>{label}</span>{count > 0 && <span className="nav-count">{count}</span>}</button>;
          })}
        </nav>

        <div className="sidebar-label collections-label">Collections <button className="small-plus" aria-label="Add collection"><Plus size={14} /></button></div>
        <div className="collection-list"><button className="collection-item"><span className="collection-icon violet"><Lightbulb size={14} /></span><span>Ideas</span><span>3</span></button><button className="collection-item"><span className="collection-icon green"><Zap size={14} /></span><span>Product</span><span>2</span></button><button className="collection-item"><span className="collection-icon orange"><BookOpen size={14} /></span><span>Reading</span><span>1</span></button></div>

        <div className="sidebar-bottom">
          <button className="utility-item" onClick={exportNotes}><Download size={16} /><span>Export notes</span></button>
          <button className="utility-item" onClick={() => fileRef.current?.click()}><Upload size={16} /><span>Import backup</span></button>
          <input ref={fileRef} type="file" accept="application/json" hidden onChange={importNotes} />
          <button className="utility-item cloud-utility" onClick={openStorage}><Cloud size={16} /><span>Cloud files</span><span className="utility-badge">{isAuthenticated ? (filesQuery.data?.length ?? 0) : "·"}</span></button>
          <button className="utility-item"><Settings2 size={16} /><span>Settings</span></button>
          <div className="profile-row"><div className="avatar">{user?.name?.slice(0, 2).toUpperCase() || "AK"}</div><div className="profile-copy"><strong>{user?.name || "Local workspace"}</strong><span>{isAuthenticated ? "Synced workspace" : "Offline-first workspace"}</span></div><MoreHorizontal size={17} className="muted-icon" /></div>
        </div>
      </aside>

      <main className="main-content">
        <header className="topbar">
          <div className="mobile-brand"><AppLogo /><span>bento<span>.</span></span></div>
          <div className="search-wrap"><Search size={17} /><input ref={searchRef} value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search your notes..." aria-label="Search notes" /><kbd><Command size={11} /> K</kbd></div>
          <div className="topbar-actions"><button className="icon-button theme-toggle" onClick={() => setTheme(theme === "dark" ? "light" : "dark")} aria-label="Toggle theme">{theme === "dark" ? <Sun size={17} /> : <Moon size={17} />}</button><button className="avatar top-avatar">AK</button></div>
        </header>

        <div className="content-wrap">
          <section className="welcome-row"><div><p className="eyebrow"><span className="eyebrow-dot" /> Wednesday, September 16, 2026</p><h1>Good evening, Alex<span className="accent-dot">.</span></h1><p className="subheading">A little space for all the things on your mind.</p></div><button className="focus-button"><Circle size={15} /> Focus mode <ChevronDown size={14} /></button></section>

          <section className="overview-grid" aria-label="Workspace overview">
            <div className="overview-card overview-primary"><div className="overview-top"><div><span className="overline">Your workspace</span><strong>{stats.total} <em>notes</em></strong></div><div className="spark-icon"><Sparkles size={17} /></div></div><div className="overview-bottom"><span><span className="live-dot" /> All synced locally</span><span>{stats.words.toLocaleString()} words captured</span></div></div>
            <div className="overview-card quick-card"><div className="quick-icon"><Zap size={18} /></div><div><span className="overline">Quick capture</span><strong>Have a thought?</strong><button onClick={openNewNote}>Write it down <span>→</span></button></div></div>
            <div className="overview-card stat-card"><span className="overline">Pinned notes</span><strong>{String(stats.pinned).padStart(2, "0")}</strong><span className="stat-caption"><Pin size={12} /> Your essentials</span></div>
            <div className="overview-card stat-card accent-stat"><span className="overline">This week</span><strong>+{Math.min(stats.total, 6)}</strong><span className="stat-caption"><CheckCircle2 size={12} /> Notes created</span></div>
          </section>

          <section className="notes-section"><div className="section-heading"><div><div className="section-title-row"><h2>{activeLabel}</h2><span className="result-count">{visibleNotes.length}</span></div><p>{view === "all" ? "Fast to capture. Easy to find. Yours to keep." : view === "trash" ? "Deleted notes stay here until you restore them." : "A focused view of your workspace."}</p></div><div className="view-controls"><div className="filter-control"><Tag size={14} /><select value={tagFilter} onChange={(e) => setTagFilter(e.target.value)} aria-label="Filter by tag">{tags.map((tag) => <option key={tag}>{tag}</option>)}</select><ChevronDown size={13} /></div><div className="filter-control"><ArrowDownAZ size={14} /><select value={sort} onChange={(e) => setSort(e.target.value as typeof sort)} aria-label="Sort notes"><option value="updated">Recently edited</option><option value="created">Recently created</option><option value="title">Title A–Z</option></select><ChevronDown size={13} /></div><div className="layout-toggle"><button className={layout === "grid" ? "active" : ""} onClick={() => setLayout("grid")} aria-label="Grid view"><LayoutGrid size={15} /></button><button className={layout === "list" ? "active" : ""} onClick={() => setLayout("list")} aria-label="List view"><List size={16} /></button></div></div></div>

            {visibleNotes.length > 0 ? <div className={`notes-grid ${layout === "list" ? "list-layout" : ""}`}>{visibleNotes.map((note, index) => <NoteCard key={note.id} note={note} index={index} onOpen={(n) => { setEditing(n); setEditorOpen(true); }} onPin={(id) => toggleField(id, "pinned")} onFavorite={(id) => toggleField(id, "favorite")} onArchive={archiveNote} onDelete={deleteNote} onRestore={restoreNote} />)}<button className="add-card" onClick={openNewNote}><span><Plus size={21} /></span><strong>Add a new note</strong><small>or press ⌘ N</small></button></div> : <div className="empty-state"><div className="empty-orb"><Search size={22} /></div><h3>No notes found</h3><p>Try a different search or start a fresh note.</p><button onClick={() => { setSearch(""); setTagFilter("All tags"); openNewNote(); }}><Plus size={15} /> Create note</button></div>}
          </section>
        </div>
      </main>

      {editorOpen && editing && <Editor note={editing} onChange={setEditing} onClose={() => setEditorOpen(false)} onSave={saveNote} onDelete={editing.trashed ? undefined : deleteNote} />}
      {storageOpen && <StoragePanel files={filesQuery.data || []} isLoading={filesQuery.isLoading} isUploading={uploadFile.isPending} onUpload={() => cloudFileRef.current?.click()} onRemove={(id) => removeFile.mutate({ id })} onClose={() => setStorageOpen(false)} />}
      <input ref={cloudFileRef} type="file" hidden onChange={uploadCloudFile} />
      {toast && <div className="toast"><Check size={15} /> {toast}</div>}
    </div>
  );
}

function Editor({ note, onChange, onClose, onSave, onDelete }: { note: Note; onChange: (note: Note) => void; onClose: () => void; onSave: (note: Note) => void; onDelete?: (id: string) => void }) {
  const isNew = !note.title && !note.content;
  return <div className="editor-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}><section className="editor-panel" role="dialog" aria-modal="true" aria-label={isNew ? "New note" : "Edit note"}><div className="editor-head"><div className="editor-context"><FileText size={16} /><span>{isNew ? "New note" : "Editing note"}</span></div><div className="editor-head-actions"><button className={`icon-button ${note.pinned ? "active" : ""}`} onClick={() => onChange({ ...note, pinned: !note.pinned })} aria-label="Pin note"><Pin size={16} /></button><button className="icon-button" onClick={onClose} aria-label="Close editor"><X size={18} /></button></div></div><div className="editor-color-strip">{colors.map((color) => <button key={color} className={`color-swatch ${color} ${note.color === color ? "selected" : ""}`} onClick={() => onChange({ ...note, color })} aria-label={`Use ${color} color`} />)}</div><input className="editor-title" autoFocus value={note.title} onChange={(e) => onChange({ ...note, title: e.target.value })} placeholder="Note title" /><textarea className="editor-textarea" value={note.content} onChange={(e) => onChange({ ...note, content: e.target.value })} placeholder="Start writing...\n\nYou can capture an idea, make a list, or leave yourself a reminder." /><div className="editor-meta"><label><Hash size={14} /> <input value={note.tag} onChange={(e) => onChange({ ...note, tag: e.target.value })} placeholder="Tag" /></label><label><Folder size={14} /> <input value={note.category} onChange={(e) => onChange({ ...note, category: e.target.value })} placeholder="Collection" /></label></div><div className="editor-footer"><div>{onDelete && <button className="delete-action" onClick={() => { onDelete(note.id); onClose(); }}><Trash2 size={14} /> Move to trash</button>}</div><div className="editor-footer-actions"><button className="cancel-button" onClick={onClose}>Cancel</button><button className="save-button" onClick={() => onSave(note)}><Check size={15} /> Save note</button></div></div></section></div>;
}

type CloudFile = {
  id: number;
  name: string;
  mimeType: string;
  size: number;
  storageUrl: string;
  createdAt: Date | string;
};

function formatFileSize(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function StoragePanel({ files, isLoading, isUploading, onUpload, onRemove, onClose }: { files: CloudFile[]; isLoading: boolean; isUploading: boolean; onUpload: () => void; onRemove: (id: number) => void; onClose: () => void }) {
  return <div className="storage-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}><section className="storage-panel" role="dialog" aria-modal="true" aria-label="Cloud files"><div className="storage-head"><div><div className="storage-kicker"><Cloud size={14} /> Secure file storage</div><h2>Cloud files</h2><p>Your attachments and backups, available across devices.</p></div><button className="icon-button" onClick={onClose} aria-label="Close cloud files"><X size={18} /></button></div><div className="storage-summary"><span><span className="live-dot" /> Private to your account</span><span>10 MB max per file</span></div><button className="storage-upload" onClick={onUpload} disabled={isUploading}><FileUp size={17} /> {isUploading ? "Uploading securely..." : "Upload a file"}<span>+</span></button><div className="storage-list">{isLoading ? <div className="storage-empty"><div className="storage-spinner" />Loading your files...</div> : files.length === 0 ? <div className="storage-empty"><div className="storage-empty-icon"><Cloud size={20} /></div><strong>No cloud files yet</strong><span>Upload a PDF, image, or backup to keep it with you.</span></div> : files.map((file) => <div className="storage-file" key={file.id}><div className="file-icon"><FileText size={17} /></div><div className="file-copy"><strong title={file.name}>{file.name}</strong><span>{formatFileSize(file.size)} · {new Date(file.createdAt).toLocaleDateString()}</span></div><a className="icon-button" href={file.storageUrl} target="_blank" rel="noreferrer" aria-label={`Open ${file.name}`} title="Open file"><ExternalLink size={15} /></a><button className="icon-button" onClick={() => onRemove(file.id)} aria-label={`Remove ${file.name}`} title="Remove"><Trash2 size={15} /></button></div>)}</div><div className="storage-note"><CheckCircle2 size={14} /><span>Files are stored separately from note text, so your notes stay fast and offline-friendly.</span></div></section></div>;
}

// Keep the type import used by the browser's event handler without adding a runtime dependency.
void (0 as unknown as React.ChangeEvent<HTMLInputElement>);
